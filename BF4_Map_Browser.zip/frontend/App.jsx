
import React, { useEffect, useState } from 'react';
import './App.css';
import axios from 'axios';

const App = () => {
  const [maps, setMaps] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/maps')
      .then(res => setMaps(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="app">
      <header className="navbar">
        <h1>BATTLEFIELD 4</h1>
        <nav>
          <a href="#">Server Browser</a>
          <a href="#">Leaderboards</a>
          <a href="#">Loadout</a>
        </nav>
      </header>

      <main>
        <div className="page-title">
          <span className="menu-icon">☰</span>
          <h2>RC3 BASEMAPS</h2>
        </div>
        <div className="map-grid">
          {maps.map((map, idx) => (
            <div key={idx} className="map-card">
              <img src={map.image} alt={map.name} />
              <h3>{map.name}</h3>
              <p>{map.mode}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default App;
