
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());

const maps = [
  { name: "DAWNBREAKER", mode: "Conquest Large", image: "https://link-to-image/dawnbreaker.jpg" },
  { name: "FLOOD ZONE", mode: "Conquest Large", image: "https://link-to-image/floodzone.jpg" },
  { name: "GOLMUD RAILWAY", mode: "Conquest Large", image: "https://link-to-image/golmud.jpg" },
  { name: "HAINAN RESORT", mode: "Conquest Large", image: "https://link-to-image/hainan.jpg" },
  { name: "LANCANG DAM", mode: "Conquest Large", image: "https://link-to-image/lancang.jpg" },
  { name: "PARACEL STORM", mode: "Conquest Large", image: "https://link-to-image/paracel.jpg" },
  { name: "ROGUE TRANSMISSION", mode: "Conquest Large", image: "https://link-to-image/rogue.jpg" },
  { name: "SIEGE OF SHANGHAI", mode: "Conquest Large", image: "https://link-to-image/shanghai.jpg" },
  { name: "ZAVOD 311", mode: "Conquest Large", image: "https://link-to-image/zavod.jpg" }
];

app.get('/api/maps', (req, res) => {
  res.json(maps);
});

app.listen(PORT, () => {
  console.log(`🔥 Server running on http://localhost:${PORT}`);
});
